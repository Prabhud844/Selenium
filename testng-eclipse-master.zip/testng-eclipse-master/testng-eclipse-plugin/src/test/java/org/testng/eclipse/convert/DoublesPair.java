package org.testng.eclipse.convert;

public class DoublesPair {

  public DoublesPair(double d, double e) {
  }

  public static DoublesPair of(double d, double e) {
    return null;
  }

  public static DoublesPair of(DoublesPair base) {
    return null;
  }

  public static DoublesPair ofNumbers(Pair<Integer, Long> base) {
    return null;
  }

  public static DoublesPair ofNumbers(DoublesPair base) {
    // TODO Auto-generated method stub
    return null;
  }

  public Object getFirst() {
    return null;
  }

  public Object getSecond() {
    return null;
  }

  public double getFirstDouble() {
    // TODO Auto-generated method stub
    return 0;
  }

  public double getSecondDouble() {
    // TODO Auto-generated method stub
    return 0;
  }

  public Object getKey() {
    return null;
  }

  public Object getValue() {
    return null;
  }

  public double getDoubleKey() {
    // TODO Auto-generated method stub
    return 0;
  }

  public double getDoubleValue() {
    // TODO Auto-generated method stub
    return 0;
  }

}
