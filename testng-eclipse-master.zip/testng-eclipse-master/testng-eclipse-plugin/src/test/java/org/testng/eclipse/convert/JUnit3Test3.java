package org.testng.eclipse.convert;

import junit.framework.TestCase;

public class JUnit3Test3 extends TestCase {

  public JUnit3Test3(String name) {
    // Should be removed
    super(name);
  }

  protected void setUp() throws Exception {
    // Should be removed
    super.setUp();
  }

  public void _testFoo() {
  }
}
