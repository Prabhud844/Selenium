package org.testng.eclipse.convert;

public class Pair<T1, T2> extends DoublesPair {

  public Pair(double d, double e) {
    super(d, e);
  }

}
